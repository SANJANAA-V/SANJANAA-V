::: {align="center"}
`<picture>`{=html}
`<source media="(prefers-color-scheme: dark)" srcset="https://capsule-render.vercel.app/api?type=waving&height=230&color=0:EF93C4,50:FF69B4,100:F8BBD0&text=SANJANAA%20V&fontSize=58&fontColor=FFFFFF&fontAlignY=38&desc=AI%2FML%20%7C%20Backend%20Engineering%20%7C%20Distributed%20Systems&descSize=16&descAlignY=60&animation=fadeIn">`{=html}
`<source media="(prefers-color-scheme: light)" srcset="https://capsule-render.vercel.app/api?type=waving&height=230&color=0:EF93C4,50:FF69B4,100:F8BBD0&text=SANJANAA%20V&fontSize=58&fontColor=FFFFFF&fontAlignY=38&desc=AI%2FML%20%7C%20Backend%20Engineering%20%7C%20Distributed%20Systems&descSize=16&descAlignY=60&animation=fadeIn">`{=html}
`<img src="https://capsule-render.vercel.app/api?type=waving&height=230&color=0:EF93C4,50:FF69B4,100:F8BBD0&text=SANJANAA%20V&fontSize=58&fontColor=FFFFFF&fontAlignY=38&desc=AI%2FML%20%7C%20Backend%20Engineering%20%7C%20Distributed%20Systems&descSize=16&descAlignY=60&animation=fadeIn" width="100%" alt="Sanjanaa V profile banner">`{=html}
`</picture>`{=html}

```{=html}
<h1>
```
Hey there, I'm Sanjanaa! 👋
```{=html}
</h1>
```
`<a href="https://readme-typing-svg.demolab.com">`{=html}`<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=500&size=19&duration=2800&pause=900&color=EF93C4&center=true&vCenter=true&width=720&lines=AI%2FML+%26+Backend+Engineering+Enthusiast;Building+systems+that+solve+real+problems;Exploring+Machine+Learning+%26+Distributed+Systems;Learn.+Build.+Measure.+Improve." alt="Typing introduction">`{=html}`</a>`{=html}

`<br>`{=html}
`<a href="https://github.com/SANJANAA-V?tab=followers">`{=html}`<img src="https://img.shields.io/github/followers/SANJANAA-V?style=for-the-badge&label=Followers&color=EF93C4&labelColor=161B22" alt="GitHub followers">`{=html}`</a>`{=html}
`<a href="https://github.com/SANJANAA-V?tab=repositories">`{=html}`<img src="https://img.shields.io/github/stars/SANJANAA-V?affiliations=OWNER%2CCOLLABORATOR&style=for-the-badge&label=Stars&color=F8BBD0&labelColor=161B22" alt="GitHub stars">`{=html}`</a>`{=html}
`<img src="https://komarev.com/ghpvc/?username=SANJANAA-V&style=for-the-badge&color=FF69B4&label=PROFILE+VIEWS" alt="Profile views">`{=html}

`<br>`{=html}`<br>`{=html}
`<a href="https://www.linkedin.com/in/sanjanaa-v-113143376/">`{=html}`<img src="https://img.shields.io/badge/LinkedIn-Connect-FF69B4?style=flat-square&logo=linkedin&logoColor=white" alt="LinkedIn">`{=html}`</a>`{=html}
`<a href="mailto:sanjanaa.v.006@gmail.com">`{=html}`<img src="https://img.shields.io/badge/Email-Contact-EF93C4?style=flat-square&logo=gmail&logoColor=white" alt="Email">`{=html}`</a>`{=html}
`<a href="https://github.com/SANJANAA-V">`{=html}`<img src="https://img.shields.io/badge/GitHub-Follow-F8BBD0?style=flat-square&logo=github&logoColor=161B22" alt="GitHub">`{=html}`</a>`{=html}
:::

------------------------------------------------------------------------

## 🌸 About Me

```{=html}
<table>
```
```{=html}
<tr>
```
```{=html}
<td width="68%" valign="middle">
```
I'm **Sanjanaa V**, a second-year Information Technology undergraduate
at **Sri Sairam Engineering College**, Chennai. I enjoy working at the
intersection of **Machine Learning, AI engineering, backend development,
and distributed systems**.

-   🎓 B.Tech Information Technology (2025--2029)
-   📊 CGPA: **9.45**
-   🤖 Interested in applied ML, model evaluation, and AI-powered
    systems.
-   ⚙️ Exploring backend engineering, event-driven architectures, and
    data infrastructure.
-   🧠 Currently building **ORION³** and **BACKLOT**.
-   💻 Strengthening Data Structures & Algorithms and core CS
    fundamentals.
-   🎯 Open to AI/ML, data science, and backend engineering internships.

*I care about understanding the problem, building a thoughtful solution,
and measuring whether it actually works.*

```{=html}
</td>
```
```{=html}
<td width="32%" align="center" valign="middle">
```
`<img src="https://github.com/SANJANAA-V.png" width="190" alt="Sanjanaa's GitHub avatar">`{=html}`<br>`{=html}`<br>`{=html}**Chennai,
India 🇮🇳**
```{=html}
</td>
```
```{=html}
</tr>
```
```{=html}
</table>
```
## 🧰 Tech Stack

::: {align="center"}
**Languages**`<br>`{=html}
`<img src="https://skillicons.dev/icons?i=python,java,c&theme=dark" alt="Python, Java and C">`{=html}

**Machine Learning & Data Science**`<br>`{=html}
`<img src="https://img.shields.io/badge/Scikit--learn-F7931E?style=for-the-badge&logo=scikitlearn&logoColor=white" alt="Scikit-learn">`{=html}
`<img src="https://img.shields.io/badge/LightGBM-2E8B57?style=for-the-badge" alt="LightGBM">`{=html}
`<img src="https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white" alt="Pandas">`{=html}
`<img src="https://img.shields.io/badge/NumPy-013243?style=for-the-badge&logo=numpy&logoColor=white" alt="NumPy">`{=html}
`<img src="https://img.shields.io/badge/Matplotlib-11557C?style=for-the-badge" alt="Matplotlib">`{=html}

**Backend, Data & Infrastructure**`<br>`{=html}
`<img src="https://skillicons.dev/icons?i=fastapi,postgres,redis,docker&theme=dark" alt="FastAPI, PostgreSQL, Redis and Docker">`{=html}
`<img src="https://img.shields.io/badge/Apache%20Kafka-231F20?style=for-the-badge&logo=apachekafka&logoColor=white" alt="Apache Kafka">`{=html}

**AI & LLM Applications**`<br>`{=html}
`<img src="https://img.shields.io/badge/Retrieval--Augmented%20Generation-8A2BE2?style=for-the-badge" alt="RAG">`{=html}
`<img src="https://img.shields.io/badge/LLM%20Applications-FF69B4?style=for-the-badge" alt="LLM applications">`{=html}

**Developer Tools**`<br>`{=html}
`<img src="https://skillicons.dev/icons?i=git,github,vscode,postman&theme=dark" alt="Git, GitHub, VS Code and Postman">`{=html}
`<img src="https://img.shields.io/badge/Google%20Colab-F9AB00?style=for-the-badge&logo=googlecolab&logoColor=white" alt="Google Colab">`{=html}
`<img src="https://img.shields.io/badge/Streamlit-FF4B4B?style=for-the-badge&logo=streamlit&logoColor=white" alt="Streamlit">`{=html}
:::

------------------------------------------------------------------------

## 🚀 Featured Projects

### 01 · ORION³ --- Pre-payment Scam-Risk Scoring

::: {align="center"}
`<a href="https://github.com/SANJANAA-V/ORION3">`{=html}`<img src="https://img.shields.io/badge/Repository-ORION%C2%B3-FF69B4?style=for-the-badge&logo=github&logoColor=white" alt="ORION3 repository">`{=html}`</a>`{=html}
`<a href="https://orion3.streamlit.app">`{=html}`<img src="https://img.shields.io/badge/Live%20Demo-Streamlit-EF93C4?style=for-the-badge&logo=streamlit&logoColor=white" alt="ORION3 live demo">`{=html}`</a>`{=html}
:::

**The problem:** Many digital-payment scams involve victims being
manipulated into authorizing transactions themselves. Systems focused
only on unauthorized transactions can miss this risk.

**What I built:** A pre-payment scam-risk scoring system that combines
payment behaviour, receiver-network signals, and suspicious message
signals to return an actionable `ALLOW`, `WARN`, or `BLOCK` decision
with plain-language reasons.

**Engineering highlights** - Built a multi-signal scam-risk scoring
pipeline and decision layer. - Served predictions through **FastAPI**,
with a measured **p95 latency of 27 ms**, and created a live
**Streamlit** demo. - On a synthetic UPI simulator with mule campaigns,
the behaviour + network model achieved **PR-AUC 0.90 (easy) / 0.38
(hard)**, compared with **0.28 / 0.02** for hand-set rules. -
Benchmarked LightGBM on the IEEE-CIS dataset (**590K transactions; 3.5%
fraud**) using a chronological split and untouched holdout: **PR-AUC
0.50, ROC-AUC 0.90**. - Trained an SMS smishing classifier with **97%
recall on unseen templates**; documented its **51% false-alarm rate on
formal legitimate messages** as a limitation.

**Stack:** `Python` · `LightGBM` · `FastAPI` · `Streamlit` ·
`scikit-learn` · `Pandas`

### 02 · BACKLOT --- Distributed Product Returns & Recovery Infrastructure

::: {align="center"}
`<a href="https://github.com/SANJANAA-V/BACKLOT">`{=html}`<img src="https://img.shields.io/badge/Repository-BACKLOT-FF69B4?style=for-the-badge&logo=github&logoColor=white" alt="BACKLOT repository">`{=html}`</a>`{=html}
`<img src="https://img.shields.io/badge/Status-In%20Progress-EF93C4?style=for-the-badge" alt="Project in progress">`{=html}
:::

**The problem:** E-commerce returns generate fragmented logistics
events, parcel metadata, product identifiers, and inspection evidence.
Missing or conflicting records make it difficult to reconstruct what
happened to a returned product.

**What I'm building:** An event-driven platform that reconstructs
product-return journeys, reconciles evidence, detects anomalies, and
supports evidence-based recovery decisions.

**Engineering work** - Designed an event-driven architecture to
correlate logistics events, parcel metadata, product identifiers, and
inspection evidence. - Implemented asynchronous **Apache Kafka**
processing with idempotent consumers, duplicate-event detection,
retries, and dead-letter queues. - Developed evidence reconciliation and
ML-based anomaly detection for missing events, product mismatches,
parcel-weight deviations, and conflicting inspection reports. -
Integrated **RAG and an LLM investigation assistant** to generate
evidence-grounded explanations and product-recovery recommendations. -
Included human review for uncertain cases.

**Stack:** `Python` · `FastAPI` · `Apache Kafka` · `PostgreSQL` ·
`Redis` · `LightGBM` · `RAG` · `LLMs` · `Docker`

------------------------------------------------------------------------

## 🎓 Education

  -------------------------------------------------------------------------
  Institution     Qualification                 Result                 Year
  --------------- --------------- -------------------- --------------------
  Sri Sairam      B.Tech,                **CGPA 9.45**           2025--2029
  Engineering     Information                          
  College         Technology                           

  VGN Chinmaya    CBSE Class XII             **91.8%**                 2025
  Vidyalaya                                            

  VGN Chinmaya    CBSE Class X                 **95%**                 2023
  Vidyalaya                                            
  -------------------------------------------------------------------------

## 💼 Experience

**Student Intern · SSN College of Engineering**\
*Summer 2024 · Chennai, India*

-   Built an Arduino-based automatic fire-extinguishing robot using
    flame sensors, a motor driver, and a water-spraying mechanism.
-   Implemented movement towards the detected flame and tested the
    prototype with a live flame.
-   Prepared technical documentation for the prototype.

## 🏆 Achievements

::: {align="center"}
`<img src="https://img.shields.io/badge/NAUKRI%20YOUNG%20TURKS%202025-TOP%202%25-FF69B4?style=for-the-badge" alt="Naukri Young Turks Top 2%">`{=html}
`<img src="https://img.shields.io/badge/TIMES%20NIE%20VISTA%20IDEATHON-1st%20RUNNER%20UP-EF93C4?style=for-the-badge" alt="Times NIE Vista Ideathon first runner-up">`{=html}
`<img src="https://img.shields.io/badge/LEETCODE-100%2B%20PROBLEMS-F8BBD0?style=for-the-badge" alt="100 plus LeetCode problems">`{=html}
:::

-   **Naukri Young Turks (2025):** Top 2% --- AIR 10,717 among 5.5 lakh
    participants.
-   **Times NIE Vista Ideathon (2023):** 1st runner-up, organized by
    Times of India with StartupTN.
-   **LeetCode:** 100+ problems solved.

## 📜 Certifications

-   **CS50P: Introduction to Programming with Python** --- Harvard
    University ·
    [Certificate](https://cs50.harvard.edu/certificates/0a99a7c5-b80c-4994-b2f9-942d74b39bee)
-   **Robotics and Embedded Systems Training** --- Rancho Labs, powered
    by IIT Delhi.
-   **Advanced Diploma in Python Programming (ADPP)** --- Computer
    Software College (CSC).

------------------------------------------------------------------------

## 📊 GitHub Analytics

::: {align="center"}
`<img height="165" src="https://github-readme-stats.vercel.app/api?username=SANJANAA-V&show_icons=true&hide_border=true&bg_color=0D1117&title_color=FF69B4&icon_color=EF93C4&text_color=F8BBD0&rank_icon=github" alt="GitHub statistics">`{=html}
`<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=SANJANAA-V&layout=compact&hide_border=true&bg_color=0D1117&title_color=FF69B4&text_color=F8BBD0" alt="Most used languages">`{=html}
`<br>`{=html}`<br>`{=html}
`<img src="https://streak-stats.demolab.com?user=SANJANAA-V&theme=dark&hide_border=true&background=0D1117&ring=FF69B4&fire=EF93C4&currStreakLabel=F8BBD0&sideLabels=EF93C4&dates=FFFFFF&currStreakNum=FF69B4&sideNums=F8BBD0" alt="GitHub contribution streak">`{=html}
`<br>`{=html}`<br>`{=html}
`<img src="https://github-readme-activity-graph.vercel.app/graph?username=SANJANAA-V&bg_color=0D1117&color=F8BBD0&line=FF69B4&point=EF93C4&area=true&hide_border=true&custom_title=Contribution%20Activity" width="100%" alt="GitHub contribution activity graph">`{=html}
:::

------------------------------------------------------------------------

## 🐍 Contribution Snake

::: {align="center"}
`<picture>`{=html}
`<source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/SANJANAA-V/SANJANAA-V/output/github-contribution-grid-snake-dark.svg">`{=html}
`<source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/SANJANAA-V/SANJANAA-V/output/github-contribution-grid-snake.svg">`{=html}
`<img alt="Contribution snake animation" src="https://raw.githubusercontent.com/SANJANAA-V/SANJANAA-V/output/github-contribution-grid-snake.svg" width="100%">`{=html}
`</picture>`{=html}
:::

------------------------------------------------------------------------

## 🤝 Connect With Me

::: {align="center"}
`<a href="https://www.linkedin.com/in/sanjanaa-v-113143376/">`{=html}`<img src="https://img.shields.io/badge/LinkedIn-Sanjanaa%20V-FF69B4?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn">`{=html}`</a>`{=html}
`<a href="mailto:sanjanaa.v.006@gmail.com">`{=html}`<img src="https://img.shields.io/badge/Email-Let's%20Talk-EF93C4?style=for-the-badge&logo=gmail&logoColor=white" alt="Email">`{=html}`</a>`{=html}
`<a href="https://github.com/SANJANAA-V">`{=html}`<img src="https://img.shields.io/badge/GitHub-SANJANAA--V-F8BBD0?style=for-the-badge&logo=github&logoColor=161B22" alt="GitHub">`{=html}`</a>`{=html}
`<br>`{=html}`<br>`{=html} *Open to conversations about AI/ML, backend
engineering, distributed systems, internships, and collaborative
projects.*
:::

::: {align="center"}
`<img src="https://capsule-render.vercel.app/api?type=waving&height=130&section=footer&color=0:EF93C4,50:FF69B4,100:F8BBD0" width="100%" alt="Pink waving footer">`{=html}

**Thanks for visiting! Built with curiosity and 💗 by Sanjanaa.**
:::
